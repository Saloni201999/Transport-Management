
package dao;

import Connection.MyCon;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import model.Transport;

public class TransportDAO {
    
     public int autoIncr() throws SQLException
    {
        String sql;
        Connection con=null;
        sql="select max(trucknono) from truck";
        int max=501;
        PreparedStatement ps=null;
        con=MyCon.getConnection();
        ps=con.prepareStatement(sql);
        ResultSet rs=null;
        rs=ps.executeQuery();
        if(rs.next())
        {     
            max=rs.getInt(1);
            max=max+1;
        }    
      return max;
    }
    public int insertTruck(Transport T)throws SQLException
    {
      String sql;
      Connection con=null;
     
      sql="insert into truck values(?,?,?,?,?)";
      PreparedStatement ps = null;
      con=MyCon.getConnection();
      ps=con.prepareStatement(sql);
      ps.setInt(1, T.getTruckno());
      ps.setString(2,T.getInsurance());
      ps.setString(3,T.getOwner());
      ps.setInt(4,T.getMobileno());
      ps.setString(5, T.getRoute());
      int n=0;
      n=ps.executeUpdate();
      System.out.println("Record inserted............");
         return 0;
     
      
    }
    public  boolean deleteByTruckNo(int truckno) throws SQLException
    {
         String sql;
       Connection con=null;
       ResultSet rs=null;
       PreparedStatement ps=null;
       con=MyCon.getConnection();  
       sql="delete from truck where truckno=?";
       ps=con.prepareStatement(sql);
       ps.setInt(1, truckno);
       int n=0;
       n=ps.executeUpdate();
       if(n>0)
           return true;
       
     return false;
    }
    public Transport searchByTruckno(int truckno) throws SQLException 
    {
        String sql;
        Connection con=null;
         ResultSet rs=null;
        con=MyCon.getConnection();
        PreparedStatement ps =null;
        sql="select * from truck where truckno=?";
        ps=con.prepareStatement(sql);
        ps.setInt(1,truckno);
        rs=ps.executeQuery();
        Transport T=new Transport();
        if(rs.next())
        {
            T.setTruckno(rs.getInt(1));
            T.setInsurance(rs.getString(2));
            T.setOwner(rs.getString(3));
            T.setMobileno(rs.getInt(4));
            T.setRoute(rs.getString(5));
        }
        else 
        {
             T=null;
        }
        return T;
   }
    public List<Transport> SearchAll() throws SQLException
    {
        String sql;
        Connection con=null;
        con=MyCon.getConnection();
        PreparedStatement ps=null;
        sql="select * from truck";
        ResultSet rs=null;
        ps=con.prepareStatement(sql);
        rs=ps.executeQuery();
    List<Transport>mylist=new ArrayList<Transport>();
    while(rs.next())
            {
                Transport T=new Transport();
                T.setTruckno(rs.getInt(1));
                T.setInsurance(rs.getString(2));
                T.setOwner(rs.getString(3));
                T.setMobileno(rs.getInt(4));
                T.setRoute(rs.getString(5));
                
                mylist.add(T);
                T=null;
            }
    return mylist;  
    } 
}