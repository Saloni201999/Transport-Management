
package model;

public class Transport 
{
    private int truckno;
    private String insurance;
    private String owner;
    private int mobileno;
    private String route;

    public int getTruckno() {
        return truckno;
    }

    public void setTruckno(int truckno) {
        this.truckno = truckno;
    }

    public String getInsurance() {
        return insurance;
    }

    public void setInsurance(String insurance) {
        this.insurance = insurance;
    }

    public String getOwner() {
        return owner;
    }

    public void setOwner(String owner) {
        this.owner = owner;
    }

    public int getMobileno() {
        return mobileno;
    }

    public void setMobileno(int mobileno) {
        this.mobileno = mobileno;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }
    
}
